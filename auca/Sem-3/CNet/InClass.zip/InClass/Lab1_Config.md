**\*\*\*\*\*\*\*\*\*\*\*# CONFIG STEPS ######\*\*\*\*\*\*\*\*\***



**0.Netwok Design and beautification.**

**1. Subnetting and IP addressing (Configuring Interfaces)**



**2. Basic settings to all devices + SSH + Standard ACL for SSH.**





**3. VLAN assigning plus all access and trunk ports on all switches**

**3.1. VTP + EtherChannel +  RSTP + Portfast and BPDUguard configs on all access ports.**





**4. Configure DHCP \& DHCP RELAY**

**5. Configure Inter-Vlan**

**6. Configure Static Routes**

**7. Configure ACL (Standard)**













**\*\*\*\*\*\*\*\*\*#### CONFIG STEPS ###\*\*\*\*\*\*\*\*\***



**1. Subnetting and IP addressing (Configuring Interfaces)**

**=========================================================**





**Masoro - Router** 

**---------------**

**en**

**conf t**

**int se2/0**

**ip address 100.100.100.1 255.255.255.252**

**no shut** 



**int se3/0** 

**ip address 150.150.150.1 255.255.255.252**

**no shut** 



**int fa6/0**

**ip address 192.168.10.17 255.255.255.240**

**no shut** 



**int fa0/0**

**no shut**

 

**int fa1/0**

**no shut** 





**ISP - Router** 

**-----------------**

**en**

**conf t**

**int se2/0** 

**ip address 100.100.100.2 255.255.255.252**

**no shut** 



**int se3/0** 

**ip address 200.200.200.2 255.255.255.252**

**no shut** 





**GISHUSHU - Router** 

**-------------------**

**en**

**conf t**

**int se3/0** 

**ip address 200.200.200.1 255.255.255.252**

**no shut** 



**int se2/0** 

**ip address 150.150.150.2 255.255.255.252**

**no shut** 



**int fa0/0**

**no shut**

 

**int fa1/0**

**no shut** 





**2. Basic settings to all devices + SSH** 

**======================================**









**3. VLAN assigning plus all access and trunk ports on all switches**

 **3.1. VTP + EtherChannel +  RSTP Portfast and BPDUguard configs on all access ports.**

**========================================================================**





**SW1\_Masoro**

**----------------**



**en**

**conf t**

**int range fa0/1-4**

**switchport mode trunk**

**switchport trunk allowed vlan 10,20,30**

**exit**







**-----------EtherChannel--------------**





**int range fa0/2-4**

**switchport mode trunk**

**channel-group 1 mode active** 

**switchport trunk allowed vlan 10,20,30**

**exit** 

**int port-channel 1** 

**switchport mode trunk**

**do wr**

**exit**





**------Verify EtherChannel-----------**



**Switch#sh etherchannel summary**







**----Output-should look like----------------------**



**1      Po1(SU)           LACP   Fa0/2(P) Fa0/3(P) Fa0/4(P)** 





**-------RSTP Congig ----------**



**Switch(config)#spanning-tree mode rapid-pvst**







**-----VTP SERVER CONFIG ------**



**vtp domain auca.ac.rw**

**vtp mode server** 

**vtp password cisco** 

**vtp version 2**





**vlan 10**

**name MANAGEMENT** 

**vlan 20** 

**name LAN\_CABLE**

**vlan 30**

**name WLAN**









**-----------PortFast \& BPDUGUARD Config------------**



**‼️‼️🛑Apply to all switches 🛑‼️‼️**

**-------------------------------------**



**en**

**conf t**

**int range fa0/5-24**

**spanning-tree portfast**

**spanning-tree bpduguard enable**





**-----ACCESS PORT CONFIG----------**



**int range fa0/5-10**

**switchport mode access** 

**switchport access vlan 20**



**int range fa0/11-15**

**switchport mode access** 

**switchport access vlan 30**



**int range fa0/20-24**

**switchport mode access** 

**switchport access vlan 10**

**do wr**



**exit**







**SW2\_Masoro**

**----------------**





**en**

**conf t**

**int range fa0/1-4**

**switchport mode trunk**

**switchport trunk allowed vlan 10,20,30**

**exit**





**-----------EtherChannel--------------**





**int range fa0/2-4**

**switchport mode trunk**

**channel-group 1 mode passive**

**switchport trunk allowed vlan 10,20,30**

**exit** 

**int port-channel 1** 

**switchport mode trunk**

**do wr**





**------Verify EtherChannel-----------**



**Switch#sh etherchannel summary**





**----Output-should look like----------------------**



**1      Po1(SU)           LACP   Fa0/2(P) Fa0/3(P) Fa0/4(P)** 





**-------RSTP Congig ----------**



**Switch(config)#spanning-tree mode rapid-pvst** 









**-----VTP SERVER CONFIG ------**





**vtp domain auca.ac.rw**

**vtp mode client**

**vtp password cisco** 

**vtp version 2**





**-----ACCESS PORT CONFIG----------**





**int range fa0/5-10**

**switchport mode access** 

**switchport access vlan 20**



**int range fa0/11-15**

**switchport mode access** 

**switchport access vlan 30**



**int range fa0/20-24**

**switchport mode access** 

**switchport access vlan 10**

**do wr**

**exit**









**‼️‼️‼️‼️‼️NOTE THIS ‼️‼️‼️‼️‼️‼️**

**---------------------------------------**





**🛑🛑🛑If you have same Addressing Scheme , The configuration is same from Masoro to Gishushu LAN , Copy and Paste there 🛑🛑🛑**









**-------------CONFIGURE DHCP 3 POOLS IN MASORO ROUTER ---------------------**



**en**

**conf t**

**ip dhcp pool MGT** 

**network 192.168.10.0 255.255.255.240**

**default-router 192.168.10.1**

**dns-server 192.168.10.14**

**exit** 

**ip dhcp pool LAN** 

**network 10.10.10.0 255.255.255.224**

**default-router 10.10.10.1**

**dns-server 192.168.10.14**

**exit**

**ip dhcp pool WLAN**

**network 172.16.0.0 255.255.255.0**

**default-router 172.16.0.1**

**dns-server 192.168.10.14**

**do wr**









**------Configure Inter Vlan ---------------**







**MASORO - ROUTER** 

**---------------** 





**int fa0/0.10**

**encapsulation dot1Q 10** 

**ip address 192.168.10.1 255.255.255.240**

**int fa0/0.20**

**encapsulation dot1Q 20**

**ip address 10.10.10.1 255.255.255.224**

**int fa0/0.30**

**encapsulation dot1Q 30**

**ip address 172.16.0.1 255.255.255.0**







**GISHUSHU - ROUTER** 

**--------------------------**











**int fa0/0.10**

**encapsulation dot1Q 10**

**ip address 192.168.11.1 255.255.255.240**

**int fa0/0.20**

**encapsulation dot1Q 20**

**ip address 20.20.20.1 255.255.255.224**

**int fa0/0.30**

**encapsulation dot1Q 30**

**ip address 172.17.0.1 255.255.255.0**











**--------- Configure STATIC ROUTES ---------------**





**MASORO - ROUTER**

**---------------**



**ip route 200.200.200.0 255.255.255.252 100.100.100.2** 

**ip route 192.168.11.0 255.255.255.240 100.100.100.2**

**ip route 20.20.20.0 255.255.255.224 100.100.100.2**

**ip route 172.17.0.0 255.255.255.0 100.100.100.2**





**ip route 200.200.200.0 255.255.255.252 150.150.150.2** 

**ip route 192.168.11.0 255.255.255.240 150.150.150.2**

**ip route 20.20.20.0 255.255.255.224 150.150.150.2**

**ip route 172.17.0.0 255.255.255.0 150.150.150.2**





**ISP - ROUTER** 

**-------------**





**ip route 192.168.10.16 255.255.255.240 100.100.100.1**

**ip route 192.168.10.0 255.255.255.240 100.100.100.1**

**ip route 10.10.10.0 255.255.255.224 100.100.100.1**

**ip route 172.16.0.0 255.255.255.0 100.100.100.1**

**ip route 192.168.11.0 255.255.255.240 100.100.100.1**

**ip route 20.20.20.0 255.255.255.224 100.100.100.1**

**ip route 172.17.0.0 255.255.255.0 100.100.100.1**

**ip route 150.150.150.0 255.255.255.252 100.100.100.1**





**ip route 192.168.10.16 255.255.255.240 200.200.200.1**

**ip route 192.168.10.0 255.255.255.240 200.200.200.1**

**ip route 10.10.10.0 255.255.255.224 200.200.200.1**

**ip route 172.16.0.0 255.255.255.0 200.200.200.1**

**ip route 192.168.11.0 255.255.255.240 200.200.200.1**

**ip route 20.20.20.0 255.255.255.224 200.200.200.1**

**ip route 172.17.0.0 255.255.255.0 200.200.200.1**

**ip route 150.150.150.0 255.255.255.252 00.100.100.1**







**GISHUSHU - ROUTER**

**------------------**





**ip route 100.100.100.0 255.255.255.252 200.200.200.2**

**ip route 192.168.10.16 255.255.255.240 200.200.200.2**

**ip route 192.168.10.0 255.255.255.240 200.200.200.2**

**ip route 10.10.10.0 255.255.255.224 200.200.200.2**

**ip route 172.16.0.0 255.255.255.0 200.200.200.2**



**ip route 100.100.100.0 255.255.255.252 150.150.150.1**

**ip route 192.168.10.16 255.255.255.240 150.150.150.1**

**ip route 192.168.10.0 255.255.255.240 150.150.150.1**

**ip route 10.10.10.0 255.255.255.224 150.150.150.1**

**ip route 172.16.0.0 255.255.255.0 150.150.150.1**







**‼️‼️‼️‼️🛑🛑🛑🛑 NOTE THIS 🛑🛑🛑🛑‼️‼️‼️‼️‼️**





**🛑🛑 Gishushu Pc's will Get Ip addresses via DHCP Server , we will configure Gishushu router as Relay agent , by configuring ip helper-address on each sub Interface 🛑🛑**



**int fa0/0.10**

**ip helper-address 192.168.10.30**

**int fa0/0.20**

**ip helper-address 192.168.10.30**

**int fa0/0.30**

**ip helper-address 192.168.10.30**







**-----Configure Standard ACL ---------------------**





**--> Deny Gishushu LAN to Ping DHCP SERVER** 





**Configure on Masoro\_Router** 

**------------------------------**



**access-list 1 deny 20.20.20.0 0.0.0.31**

**access-list 1 permit any**



**Apply on Interface**

**---------------------**



**int fa6/0**

**ip access-group 1 out** 







































